# lanjutkan-cubechat  (catatan serah-terima proyek)

Kode pemicu: ketik **lanjutkan-cubechat** di chat baru, lalu unggah file ini + `CubeChat-project.zip`.

## Instruksi untuk Claude di chat baru
Kalau pengguna menulis "lanjutkan-cubechat": baca file ini, ringkas status dalam 3 kalimat, minta
build log Actions (artifact `build-log`) kalau ada, lalu lanjut dari "Langkah berikutnya".
Verifikasi API MCPL sudah dilakukan (lihat "Hasil verifikasi"); langkah pertama sekarang = jalankan build di Actions dan perbaiki dari log.
Proyek lain di chat yang sama tidak ada hubungannya dengan file ini.

## Tujuan
Aplikasi Android mirip EnderChat/ChatCraft untuk Minecraft Java, **hanya versi 1.21.11**, dibuild lewat
**GitHub Actions**. Fokus: komunikasi dengan server + fisika (gravitasi dll) supaya server melihat
pemain yang "hidup" seperti client asli. Pengguna berbahasa Indonesia, memakai HP (app mobile).

## Keputusan yang sudah diambil
- TIDAK menjalankan client asli lewat JVM ala Zalith: berat (Java 21, OpenGL/LWJGL, RAM besar),
  Zalith GPL-3.0, dan EULA Mojang melarang membundel file game di APK.
- Pakai **MCProtocolLib** (GeyserMC, MIT) sebagai lapisan protokol. Library ini TIDAK punya dunia/fisika,
  jadi fisika ditulis sendiri (`world/Physics.kt`).
- Satu versi saja (1.21.11) agar kode sederhana. Server lebih lama hanya bisa dimasuki lewat ViaVersion/ViaBackwards.
- v0.1 mode offline dulu (login Microsoft menyusul). Nama app "CubeChat", tidak memakai kata "Minecraft";
  README memuat disclaimer "bukan produk resmi". Tidak ada aset Mojang di repo/APK.

## Stack
Kotlin 2.0.21, Jetpack Compose (BOM 2024.12.01), AGP 8.7.3, Gradle 8.10.2 (lewat `gradle/actions/setup-gradle`,
TANPA gradle wrapper), JDK 21 di CI, minSdk 26 + core library desugaring, package `com.example.cubechat`.
Dependensi protokol: `org.geysermc.mcprotocollib:protocol:1.21.11-1` (repo `repo.opencollab.dev/main/`
dan `/maven-releases/`; fallback: build dari source ke mavenLocal di CI).

## Isi proyek
- `.github/workflows/build.yml`: unduh jar server 1.21.11 dari Mojang -> data generator `--reports` ->
  `tools/gen_blockdata.py` -> `app/src/main/assets/blockdata.txt` -> `gradle :app:assembleDebug` ->
  upload artifact `CubeChat-debug-apk` (dan `build-log` kalau gagal).
- `tools/gen_blockdata.py`: ubah `blocks.json` jadi daftar rentang ID state tembus ("N a-b") dan fluida ("F a-b")
  berdasarkan daftar nama. Sudah diuji dengan data tiruan.
- `net/McClient.kt` (314 baris): SEMUA pemanggilan MCProtocolLib. Connect, handle paket, chunk, tick 50 ms.
- `net/Chat.kt`: Component -> teks berwarna (terjemahan dasar chat.type.text dll).
- `world/World.kt`: BlockData + penyimpan chunk (CharArray 4096 per section, null = udara; chunk belum
  dimuat dianggap padat; prune radius 5).
- `world/Physics.kt`: gravitasi 0,08, drag 0,98, gesekan 0,6*0,91, kotak 0,6x1,8, tabrakan per sumbu (Y dulu),
  air (x0,8 / -0,02), "di dalam blok padat" = diam (agar tidak tenggelam di slab).
- `MainActivity.kt`: ViewModel + Compose (form connect, daftar chat berwarna, input, HUD x/y/z + onGround).

## Status (diperbarui 15 Okt 2026, sesi kedua - sudah ada internet)
- Kode masih **BELUM PERNAH DIKOMPILASI** (sandbox sesi ini tidak bisa menjangkau Maven Central/Google Maven,
  jadi Gradle tidak bisa dijalankan). Yang dikerjakan: verifikasi semua pemanggilan MCProtocolLib langsung
  terhadap source commit rilis `5863712e0538bcbfbe78340ecb1acbac26b0d4d4` ("1.21.11 Release") dan perbaikan `McClient.kt`.
- Logika fisika diuji lewat port Python (sesi pertama): jatuh 10 blok mendarat di y=64.0, vy berdiri -0,0784.
- Workflow YAML valid. Build nyata baru terjadi saat dijalankan di GitHub Actions.

## Hasil verifikasi (sesi kedua)
1. **Versi MCPL**: yang benar `org.geysermc.mcprotocollib:protocol:1.21.11-1` (BUKAN `-SNAPSHOT`). Dipakai di
   `app/build.gradle.kts`. Bytecode target Java 17 (cocok dgn app), protocolVersion 774. Master MCPL sekarang sudah
   di 26.3, jadi 1.21.11 hanya ada di commit rilis di atas. Keberadaan artefak di repo.opencollab.dev TIDAK bisa
   dicek dari sandbox; workflow punya langkah fallback: kalau pom 1.21.11-1 tidak ada, MCPL dibangun dari commit itu
   ke mavenLocal (`JITPACK=true` melewati signing; wrapper MCPL = Gradle 8.5, cocok dgn JDK 21).
2. **Dependensi transitif MCPL**: netty-all 4.2.1, gson, Adventure 4.25.0, cloudburst nbt/math, fastutil (nukkitx),
   **MinecraftAuth 5.0.0** (sudah ikut; ada di Maven Central; pakai `JavaAuthManager` untuk login Microsoft nanti).
   Repo di settings: google, mavenCentral, opencollab `/main/` + `/maven-releases/`, jitpack, mavenLocal (khusus grup MCPL).
3. **Perbaikan API di McClient.kt** (nama tebakan lama -> yang benar):
   - `ClientboundPlayerPositionPacket.teleportId` -> `id`; ada `relatives: List<PositionElement>` (sekarang dipakai
     untuk flag teleport relatif X/Y/Z, DELTA_*, Y_ROT/X_ROT; `ROTATE_DELTA` belum).
   - `ClientboundSetEntityMotionPacket.motionX/Y/Z` -> `movement` (Vector3d).
   - `ServerboundChatPacket(message, timeStamp: Long, salt, signature, offset, BitSet, checksum: Int)` (bukan Instant, ada checksum).
   - `ServerboundPlayerLoadedPacket` -> `.INSTANCE` (konstruktor privat).
   - `MinecraftTypes.readChunkSection(buf, blockStateRegistrySize, biomeRegistrySize)`; hasilnya `blockData`/`getBlock(x,y,z)`
     (bukan `chunkData`). Ukuran registry hanya mempengaruhi penulisan palet, tidak pengaruh ke pembacaan.
   - Offline UUID kini `UUID.nameUUIDFromBytes("OfflinePlayer:<nama>")` lewat `GameProfile(UUID, String)`.
   - Server online-mode: MCPL melempar `UnexpectedEncryptionException` -> app menampilkan pesan jelas.
   Sudah cocok dgn source (tidak perlu diubah): `ClientNetworkSessionFactory.setRemoteSocketAddress/setProtocol/create`,
   `ClientSession.connect()`, `SessionAdapter.packetReceived/disconnected`, `DisconnectedEvent.reason`, semua nama paket
   + paket Kotlin (import `*` mencakup semuanya), `ClientCommand.RESPAWN`, `commonPlayerSpawnInfo.worldName` (Key),
   `ClientboundSystemChatPacket.content/overlay`, `PlayerChat` (`unsignedContent`, `content`, `name`), `DisguisedChat`
   (`message`, `name`), semua paket serverbound gerak. Chat.kt cocok dgn Adventure 4.25 (`arguments()`, `fallback()`).
4. Risiko Android yang tersisa: `UUIDUtils` MCPL memakai `java.util.HexFormat` (Java 17, tidak ada di Android
   dan tidak ditangani desugaring) tetapi hanya di jalur auth online (`convertToDashed`: parse profil), BUKAN jalur offline.
   Perlu dicek lagi saat login Microsoft. Selain itu netty-all besar; kemungkinan warning D8, belum diuji.

## Log build pertama di Actions (15 Okt 2026) dan perbaikannya
- Berhasil: ekstrak zip, data blok, **artefak MCPL 1.21.11-1 ADA di repo.opencollab.dev** (fallback source tidak terpakai),
  resolusi dependensi, 23 task Gradle jalan.
- Gagal di `:app:checkDebugDuplicateClasses`: `org.cloudburstmc.math:api:2.0` dan `:immutable:2.0` berisi kelas sama
  (immutable = fat jar hasil maven-shade, berisi api + implementasi ServiceLoader). Perbaikan: `exclude(group="org.cloudburstmc.math", module="api")`
  di `app/build.gradle.kts` (immutable tetap dipakai).
- Belum diketahui: apakah `compileDebugKotlin` punya error (task itu baru mulai saat build dihentikan), dan tahap dex/merge resource sesudahnya.

## Belum terverifikasi (sekarang tinggal ini)
1. Build Gradle sebenarnya di Actions (error Kotlin/D8/dex/duplicate-class bisa saja muncul; minta artifact `build-log`).
2. Perintah data generator `java -DbundlerMainClass=net.minecraft.data.Main -jar server.jar --reports --output out`
   untuk jar server 1.21.11 dan struktur `blocks.json` (states[].id, properties) - jar tidak bisa diunduh dari sandbox.
3. Perilaku runtime di perangkat: netty di Android, resolusi DNS (`InetSocketAddress(host, port)`), diterima server nyata.

## Batasan v0.1
- Hanya offline-mode; tanpa login Microsoft & chat signing (server enforce-secure-profile=true akan menolak chat).
- Slab/tangga/pagar dianggap kubus penuh -> bisa memicu kick "Flying is not enabled" di server tertentu.
- Resource pack, SRV record belum ada. Flag `ROTATE_DELTA` pada teleport belum ditangani.
- Tidak ada foreground service (koneksi putus saat app dimatikan Android). Dimensi custom ditebak dari nama dunia.

## Langkah berikutnya (urut)
1. Build hijau: jalankan Actions, perbaiki error dari artifact `build-log` (MCPL 1.21.11-1 + fallback source sudah disiapkan).
2. Uji ke server nyata (mis. Paper 1.21.11 offline-mode atau yang punya ViaVersion): chat, teleport, mendarat.
3. Login Microsoft (device code, library MinecraftAuth by RaphiMC) + chat session/signing.
4. Foreground service + notifikasi supaya tetap online di background.
5. Resource pack prompt, SRV record (mis. dnsjava), flag teleport relatif, daftar server tersimpan.
6. Bentuk collision blok parsial (slab/tangga) dari dataset collision shapes.
7. Opsional: gerak/lompat dan input, tab list, auto-reconnect.
